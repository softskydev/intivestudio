<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?= @$seo ? @$seo['title'] : 'Intive Studio' ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= @$seo['desc'] ?>">
    <meta name="keyword" content="<?= @$seo['keyword'] ?>">

    <!-- Begin loading animation -->
    <link href="<?php echo base_url('assets/css/loaders/loader-pulse.css') ?>" rel="stylesheet" type="text/css" media="all" />
    <!-- End loading animation -->
    <link href="<?php echo base_url('assets/css/theme.css') ?>" rel="stylesheet" type="text/css" media="all" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,400i,600,700&display=swap" rel="stylesheet">
  </head>

  <body>
    <div class="loader">
      <div class="loading-animation"></div>
    </div>
    <!-- <div class="alert alert-dismissible d-none d-md-block bg-primary-3 text-white py-4 py-md-3 px-0 mb-0 rounded-0 border-0">
    <div class="container">
        <div class="row no-gutters align-items-md-center justify-content-center">
            <div class="col-lg-11 col-md d-flex flex-column flex-md-row align-items-md-center justify-content-lg-center">
                <div class="mb-3 mb-md-0"><strong>Intro Sale</strong> $10 per license for Jumpstart's launch. Act fast, ends soon.</div>
                <a class="btn btn-sm btn-success ml-md-3" target="_blank" href=#>Redeem Offer</a>
            </div>
            <div class="col-auto position-absolute right">
                <button type="button" class="close p-0 position-relative" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                        <img src="assets/img/icons/interface/icon-x.svg" alt="Close" class="icon icon-sm bg-white" data-inject-svg>
                    </span>
                </button>
            </div>
        </div>
    </div>
</div> -->
    <div class="navbar-container">
      <nav class="navbar navbar-expand-lg navbar-light" data-sticky="top">
        <div class="container">
          <a class="navbar-brand navbar-brand-dynamic-color fade-page" href="<?= base_url() ?>">
            <img alt="Jumpstart" data-inject-svg src="<?= base_url('assets/img/logos/jumpstart.svg') ?>">
          </a>
          <div class="d-flex align-items-center order-lg-3">
            <a href="#" class="btn btn-primary ml-lg-4 mr-3 mr-md-4 mr-lg-0 d-none d-sm-block order-lg-3">Contact Us</a>
            <button aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target=".navbar-collapse" data-toggle="collapse" type="button">
              <img alt="Navbar Toggler Open Icon" class="navbar-toggler-open icon icon-sm" data-inject-svg src="<?= base_url('assets/img/icons/interface/icon-menu.svg') ?>">
              <img alt="Navbar Toggler Close Icon" class="navbar-toggler-close icon icon-sm" data-inject-svg src="<?= base_url('assets/img/icons/interface/icon-x.svg') ?>">
            </button>
          </div>
          <div class="collapse navbar-collapse order-3 order-lg-2 justify-content-lg-end" id="navigation-menu">
            <ul class="navbar-nav my-3 my-lg-0">
              <li class="nav-item">
                <a  class="nav-link nav-item" href="<?= base_url('client') ?>" role="button">Our Client</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>

    <?= $content ?>

    <footer class="bg-primary-3 text-white links-white pb-4 footer-1">
      <div class="container">
        <div class="row">
          <div class="col-xl-auto mr-xl-5 col-md-3 mb-4 mb-md-0">
            <h5>Demos</h5>
            <ul class="nav flex-row flex-md-column">
              <li class="nav-item mr-3 mr-md-0">
                <a href="landing-1.html" class="nav-link fade-page px-0 py-2">Landing 1</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="landing-2.html" class="nav-link fade-page px-0 py-2">Landing 2</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="landing-3.html" class="nav-link fade-page px-0 py-2">Landing 3</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="landing-4.html" class="nav-link fade-page px-0 py-2">Landing 4</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="landing-5.html" class="nav-link fade-page px-0 py-2">Landing 5</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="landing-6.html" class="nav-link fade-page px-0 py-2">Landing 6</a>
              </li>
            </ul>
          </div>
          <div class="col-xl-auto mr-xl-5 col-md-3">
            <h5>Pages</h5>
            <ul class="nav flex-row flex-md-column">
              <li class="nav-item mr-3 mr-md-0">
                <a href="company-about-1.html" class="nav-link fade-page px-0 py-2">Company</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="blog-listing-1.html" class="nav-link fade-page px-0 py-2">Blog</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="help-center-home.html" class="nav-link fade-page px-0 py-2">Help Center</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="careers-1.html" class="nav-link fade-page px-0 py-2">Careers</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="case-studies.html" class="nav-link fade-page px-0 py-2">Case Studies</a>
              </li>
              <li class="nav-item mr-3 mr-md-0">
                <a href="pricing-plans.html" class="nav-link fade-page px-0 py-2">Pricing</a>
              </li>
            </ul>
          </div>
          <div class="col mt-4 mt-md-0 mt-lg-5 mt-xl-0 order-lg-4 order-xl-3">
            <h5>Articles</h5>
            <ul class="list-unstyled d-flex flex-wrap">
              <li class="col-12 col-lg-6 col-xl-12 px-0">
                <div class="row my-2 my-md-3">
                  <a class="col-5" href="#">
                    <img class="rounded img-fluid hover-fade-out" src="assets/img/blog/thumb-2.jpg" alt="blog.1.image">
                  </a>
                  <div class="col">
                    <a class="h6" href="#">Unveiling our new vision for Jumpstart</a>
                    <div class="text-small text-muted mt-2">October 10th</div>
                  </div>
                </div>
              </li>
              <li class="col-12 col-lg-6 col-xl-12 px-0">
                <div class="row my-2 my-md-3">
                  <a class="col-5" href="#">
                    <img class="rounded img-fluid hover-fade-out" src="assets/img/blog/thumb-1.jpg" alt="blog.2.image">
                  </a>
                  <div class="col">
                    <a class="h6" href="#">Making the most of team-building sessions</a>
                    <div class="text-small text-muted mt-2">October 2nd</div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div class="col-lg mt-2 mt-md-5 mt-lg-0 order-lg-3 order-xl-4">
            <h5>Newsletter</h5>
            <div class="card card-body bg-white">
              <p>Get a bi-weekly digest of great articles</p>
              <form data-form-email novalidate action="/forms/mailchimp.php" id="subscribe">
                <div class="d-flex flex-column flex-sm-row form-group">
                  <input class="form-control mr-sm-2 mb-2 mb-sm-0 w-auto flex-grow-1" name="email" placeholder="Email Address" type="email" required>
                  <button type="button" class="btn btn-primary btn-loading" data-loading-text="Sending">
                    <span>Go</span>
                  </button>
                </div>
                <div class=" alert alert-success w-100" role="alert" id="alert-success" style="display: none">
                  Thanks, a member of our team will be in touch shortly.
                </div>
                <div class=" alert alert-danger w-100" role="alert" id="alert-error" style="display: none">
                  Please fill all fields correctly.
                </div>
                <div class="text-small text-muted">We'll never share your email address</div>
              </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <hr>
          </div>
        </div>
        <div class="row flex-column flex-lg-row align-items-center justify-content-center justify-content-lg-between text-center text-lg-left">
          <div class="col-auto">
            <div class="d-flex flex-column flex-sm-row align-items-center text-small">
              <div class="text-muted">&copy; <?= date('Y') ?> Page protected by reCAPTCHA and subject to Google's <a href="https://www.google.com/policies/privacy/" target="_blank">Privacy Policy</a> and <a href="https://policies.google.com/terms" target="_blank">Terms of Service</a>
              </div>
            </div>
          </div>
          <div class="col-auto mt-3 mt-lg-0">
            <ul class="list-unstyled d-flex mb-0">
              <li class="mx-3">
                <a href="#" class="hover-fade-out">
                  <img src="assets/img/icons/social/dribbble.svg" alt="Dribbble" class="icon icon-xs bg-white" data-inject-svg>
                </a>
              </li>
              <li class="mx-3">
                <a href="#" class="hover-fade-out">
                  <img src="assets/img/icons/social/twitter.svg" alt="Twitter" class="icon icon-xs bg-white" data-inject-svg>
                </a>
              </li>
              <li class="mx-3">
                <a href="#" class="hover-fade-out">
                  <img src="assets/img/icons/social/github.svg" alt="Github" class="icon icon-xs bg-white" data-inject-svg>
                </a>
              </li>
              <li class="mx-3">
                <a href="#" class="hover-fade-out">
                  <img src="assets/img/icons/social/facebook.svg" alt="Facebook" class="icon icon-xs bg-white" data-inject-svg>
                </a>
              </li>
              <li class="mx-3">
                <a href="#" class="hover-fade-out">
                  <img src="assets/img/icons/social/google.svg" alt="Google" class="icon icon-xs bg-white" data-inject-svg>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
    <a href="#top" class="btn btn-primary rounded-circle btn-back-to-top" data-smooth-scroll data-aos="fade-up" data-aos-offset="2000" data-aos-mirror="true" data-aos-once="false">
      <img src="assets/img/icons/interface/icon-arrow-up.svg" alt="Icon" class="icon bg-white" data-inject-svg>
    </a>
    <!-- Required vendor scripts (Do not remove) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/popper.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>

    <!-- Optional Vendor Scripts (Remove the plugin script here and comment initializer script out of index.js if site does not use that feature) -->

    <!-- AOS (Animate On Scroll - animates elements into view while scrolling down) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/aos.js') ?>"></script>
    <!-- Clipboard (copies content from browser into OS clipboard) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/clipboard.min.js') ?>"></script>
    <!-- Fancybox (handles image and video lightbox and galleries) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.fancybox.min.js') ?>"></script>
    <!-- Flatpickr (calendar/date/time picker UI) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/flatpickr.min.js') ?>"></script>
    <!-- Flickity (handles touch enabled carousels and sliders) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/flickity.pkgd.min.js') ?>"></script>
    <!-- Ion rangeSlider (flexible and pretty range slider elements) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/ion.rangeSlider.min.js') ?>"></script>
    <!-- Isotope (masonry layouts and filtering) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/isotope.pkgd.min.js') ?>"></script>
    <!-- jarallax (parallax effect and video backgrounds) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/jarallax.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/jarallax-video.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/jarallax-element.min.js') ?>"></script>
    <!-- jQuery Countdown (displays countdown text to a specified date) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.countdown.min.js') ?>"></script>
    <!-- jQuery smartWizard facilitates steppable wizard content -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.smartWizard.min.js') ?>"></script>
    <!-- Plyr (unified player for Video, Audio, Vimeo and Youtube) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/plyr.polyfilled.min.js') ?>"></script>
    <!-- Prism (displays formatted code boxes) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/prism.js') ?>"></script>
    <!-- ScrollMonitor (manages events for elements scrolling in and out of view) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/scrollMonitor.js') ?>"></script>
    <!-- Smooth scroll (animation to links in-page)-->
    <script type="text/javascript" src="<?php echo base_url('assets/js/smooth-scroll.polyfills.min.js') ?>"></script>
    <!-- SVGInjector (replaces img tags with SVG code to allow easy inclusion of SVGs with the benefit of inheriting colors and styles)-->
    <script type="text/javascript" src="<?php echo base_url('assets/js/svg-injector.umd.production.js') ?>"></script>
    <!-- TwitterFetcher (displays a feed of tweets from a specified account)-->
    <script type="text/javascript" src="<?php echo base_url('assets/js/twitterFetcher_min.js') ?>"></script>
    <!-- Typed text (animated typing effect)-->
    <script type="text/javascript" src="<?php echo base_url('assets/js/typed.min.js') ?>"></script>
    <!-- Required theme scripts (Do not remove) -->
    <script type="text/javascript" src="<?php echo base_url('assets/js/theme.js') ?>"></script>
    <!-- Removes page load animation when window is finished loading -->
    <script type="text/javascript">

      window.addEventListener("load",function(){document.querySelector('body').classList.add('loaded');});
      $('.btn-loading').on('click',function(event) {
        $.ajax({
          url: "<?= base_url('client/save_email') ?>",
          type: 'POST',
          dataType: 'json',
          data: $('#subscribe').serialize(),
          success: function(data){
            if (data.status == 'success') $('#alert-success').show()
          }
        })
      });
    </script>

  </body>

</html>
