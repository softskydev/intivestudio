<section class="p-0 border-top border-bottom row no-gutters">
      <div class="col-lg-7 col-xl-6">
        <div class="container min-vh-lg-80 d-flex align-items-center">
          <div class="row justify-content-center">
            <div class="col col-md-10 col-xl-9 text-center text-lg-left">
              <section>
                <div data-aos="fade-right">
                  <h1 class="display-3">
                    <?php $spword = explode(' ', $headers['home-header-1']['title'], 3) ?>
                    <mark data-aos="highlight-text" data-aos-delay="200"><?= $spword[0].' '.$spword[1] ?></mark> 
                    <?= $spword[2] ?></h1> 
                    <p class="lead"><?= $headers['home-header-1']['content'] ?></p>
                </div>
                <div class="d-flex flex-column flex-sm-row mt-4 mt-md-5 justify-content-center justify-content-lg-start" data-aos="fade-right" data-aos-delay="300">
                  <a href="#" class="btn btn-primary btn-lg mx-sm-2 mx-lg-0 mr-lg-2 my-1 my-sm-0">View Demos</a>
                  <a href="#" class="btn btn-outline-primary btn-lg mx-sm-2 mx-lg-0 mr-lg-2 my-1 my-sm-0">Purchase</a>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-5 col-xl-6 d-lg-flex flex-lg-column">
        <div class="divider divider-side transform-flip-y bg-white d-none d-lg-block"></div>
        <div class="d-lg-flex flex-column flex-fill controls-hover" data-flickity='{ "imagesLoaded": true, "wrapAround":true, "pageDots":false, "autoPlay":true }'>
          <?php foreach ($carousel as $car): ?>
            <div class="carousel-cell text-center">
              <img class="img-fluid" src="<?= $car->src ?>" alt="Image">
            </div>
          <?php endforeach ?>
        </div>
      </div>
    </section>
    <section class="bg-light o-hidden">
      <div class="container">
        <div class="row section-title justify-content-center text-center">
          <div class="col-md-9 col-lg-8 col-xl-7">
            <h2 class="display-4"><?= $headers['home-header-2']['title'] ?></h2>
            <div class="lead"><?= $headers['home-header-2']['content'] ?></div>
          </div>
        </div>
        <div class="row align-items-center justify-content-around">
          <div class="col-md-9 col-lg-5" data-aos="fade-in">
            <img src="<?= base_url($image['img-home-1']['src']) ?>" alt="Image" class="img-fluid rounded shadow">
            <img src="<?= base_url($image['img-home-mini-1']['src']) ?>" alt="Image" class="position-absolute p-0 col-4 col-xl-5 border border-white border-thick rounded-circle top left shadow-lg mt-5 ml-n5 ml-lg-n3 ml-xl-n5 d-none d-md-block" data-jarallax-element="-20 0">
          </div>
          <div class="col-md-9 col-lg-6 col-xl-5 mt-4 mt-md-5 mt-lg-0">
            <ol class="list-unstyled p-0">
              <?php foreach ($step as $st => $s): ?>
                <li class="d-flex align-items-start my-4 my-md-5">
                  <div class="rounded-circle p-3 p-sm-4 d-flex align-items-center justify-content-center bg-success">
                    <div class="position-absolute text-white h5 mb-0"><?= $st+1 ?></div>
                  </div>
                  <div class="ml-3 ml-md-4">
                    <h4><?= $s->header ?></h4>
                    <p>
                      <?= $s->body ?>
                    </p>
                    <?php if ($s->url and $s->url_string): ?>
                      <a href="<?= $s->url ?>"><?= $s->url_string ?></a>
                    <?php endif ?>
                  </div>
                </li>
              <?php endforeach ?>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <section class="p-0 bg-light">
      <div class="container">
        <div class="row align-items-center justify-content-around">
          <div class="col-md-9 col-lg-6 col-xl-5 mb-4 mb-md-5 mb-lg-0 pl-lg-5 pl-xl-0">
            <div class="text-center text-lg-left">
              <h2 class="h1"><?= $headers['home-header-3']['title'] ?></h2>
              <p class="lead"><?= $headers['home-header-3']['content'] ?></p>
            </div>
            <div id="faq-accordion">
              <?php $limit = count($feature) < 2 ? count($feature) : 2; ?>
              <?php for ($i = 0; $i < $limit; $i++) : ?>
              <div class="card mb-2 mb-md-3">
                <a href="#accordion-1" data-toggle="collapse" role="button" aria-expanded="false" class="p-3 p-md-4">
                  <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 mr-2"><?= ucwords($feature[$i]->name) ?></h6>
                    <img src="<?php echo base_url('assets/img/icons/interface/icon-caret-right.svg') ?>" alt="Caret Right" class="icon icon-sm" data-inject-svg>
                  </div>
                </a>
                <div class="collapse" id="accordion-1" data-parent="#faq-accordion">
                  <div class="px-3 px-md-4 pb-3 pb-md-4">
                    <?= $feature[$i]->content ?>
                  </div>
                </div>
              </div>
              <?php endfor ?>
            </div>
          </div>
          <div class="col-md-9 col-lg-5" data-aos="fade-in">
            <img src="<?= base_url($image['img-home-2']['src']) ?>" alt="Image" class="img-fluid rounded shadow">
            <img src="<?= base_url($image['img-home-mini-2']['src']) ?>" alt="Image" class="position-absolute p-0 col-4 col-xl-5 border border-white border-thick rounded-circle top right shadow-lg mt-5 mr-n5 mr-lg-n3 mr-xl-n5 d-none d-md-block" data-jarallax-element="-20 0">
          </div>

        </div>
      </div>
      <div class="divider divider-bottom bg-white"></div>
    </section>
    <section>
      <div class="container">
        <div class="row section-title justify-content-center text-center">
          <div class="col-md-9 col-lg-8 col-xl-7">
            <?php $spword = explode(' ', $headers['home-header-4']['title'], 3) ?>
            <h3 class="display-4"><?= $spword[0] ?> <mark data-aos="highlight-text" data-aos-delay="300"><?= $spword[1] ?> </mark> <?= @$spword[2] ?> </h3>
            <div class="lead"><?= $headers['home-header-4']['content'] ?></div>
          </div>
        </div>
        <div class="row">
          <?php $limit = count($clients) > 3 ? 3 : count($clients) ?>
          <?php for ($i = 0; $i < $limit; $i++) : ?>
            <div class="col-md-6 col-lg-4 mb-3 mb-md-4 mb-lg-0">
              <div class="card h-100 hover-box-shadow">
                <div class="d-block bg-gradient rounded-top position-relative">
                  <img class="card-img-top hover-fade-out" src="<?= $clients[$i]->img ?>" alt="Image accompanying Circle testimonial">
                  <div class="badge badge-light">
                    <img src="<?= $clients[$i]->logo ?>" alt="<?= $clients[$i]->name ?> company logo" class="icon icon-sm m-lg-1">
                  </div>
                </div>
                <div class="card-body">
                  <h3><?= $clients[$i]->name ?></h3>
                  <p>
                    <?= $clients[$i]->content ?>
                  </p>
                  <a href="<?= base_url('client/'.$clients[$i]->name) ?>" class="stretched-link">Read Story</a>
                </div>
              </div>
            </div>
          <?php endfor ?>
        </div>
      </div>
    </section>
    <section class="bg-primary-3 pt-0 text-white">
      <div class="divider divider-top transform-flip-x bg-white"></div>
      <div class="container">
        <div class="row section-title justify-content-center text-center">
          <div class="col-md-9 col-lg-8 col-xl-7">
            <h3 class="display-4"><?= $headers['home-header-5']['title'] ?></h3>
            <div class="lead"><?= $headers['home-header-5']['content'] ?></div>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-xl-9 col-lg-10">
            <div class="row justify-content-center">
              <?php $limit = count($feature) < 4 ? count($feature) : 4; ?>
              <?php for ($i = 0; $i < $limit; $i++) : ?>
                <div class="col-md-6 mb-3 mb-md-4" data-aos="fade-up" data-aos-delay="10">
                  <div class="card card-body bg-white min-vh-md-30 hover-box-shadow">
                    <div class="flex-fill">
                      <h4 class="h3"><?= ucwords($feature[$i]->name) ?></h4>
                      <p><?= $feature[$i]->content ?></p>
                    </div>
                    <a href="<?= $feature[$i]->url ?>" class="stretched-link">Learn More</a>
                  </div>
                </div>
              <?php endfor; ?>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="bg-primary text-white">
      <div class="container">
        <div class="row section-title justify-content-center text-center">
          <div class="col-md-9 col-lg-8 col-xl-7">
            <h3 class="display-4"><?= $headers['home-header-6']['title'] ?></h3>
            <div class="lead"><?= $headers['home-header-6']['content'] ?></div>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col d-flex flex-wrap justify-content-center">
            <?php foreach ($customers as $c): ?>
              <div class="m-2">
                <div class="media rounded align-items-center pl-3 pr-3 pr-md-4 py-2 shadow-sm bg-white">
                  <img src="<?php echo base_url($c->img) ?>" alt="Brandon Pliskin avatar image" class="avatar avatar-sm flex-shrink-0 mr-3">
                  <div class="text-dark mb-0"><?= $c->content ?></div>
                </div>
              </div>
            <?php endforeach ?>
          </div>
        </div>
      </div>
    </section>
    <section class="pb-0">
      <div class="container">
        <div class="row section-title justify-content-center text-center">
          <div class="col-md-9 col-lg-8 col-xl-7">
            <h3 class="display-4"><?= $footer['footer-1']['title'] ?></h3>
            <div class="lead"><?= $footer['footer-1']['content'] ?></div>
          </div>
        </div>
        <?php if ($footer['footer-1']['nb']): ?>
          <div class="row justify-content-center text-center mt-md-n4">
            <div class="col-auto">
              <a href="#" class="btn btn-primary btn-lg"><?= $footer['footer-1']['nb'] ?></a>
            </div>
          </div>
        <?php endif ?>
      </div>
      <div class="divider divider-bottom bg-primary-3 mt-5"></div>
    </section>