<section class="bg-light py-5">
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="d-flex flex-column flex-lg-row no-gutters border rounded bg-white o-hidden">
					<a href="<?= base_url('client/'.str_replace(' ', '-', $image->name)) ?>" class="d-block position-relative bg-gradient col-xl-6 order-lg-2">
						<div class="divider divider-side transform-flip-y d-none d-lg-block"></div>
						<img class="card-img-top flex-fill hover-fade-out" src="<?= base_url($image->img) ?>" alt="Image accompanying Amara testimonial">
						<div class="badge badge-light badge-pill">
							<img src="<?= base_url($image->logo) ?>" alt="Aven company logo" class="icon icon-sm m-1 m-lg-2">
						</div>
					</a>
					<div class="p-4 p-md-5 col-xl">
						<div class="p-lg-4 p-xl-5">
							<h1><?= $headers['clients-header-1']['title'] ?></h1>
							<p class="lead">
								<?= $headers['clients-header-1']['content'] ?>
							</p>
							<a href="<?= base_url('client/'.str_replace(' ', '-', $image->name)) ?>" class="lead stretched-link">Read Story</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row mt-3 mt-lg-5">
			<?php $limit = count($clients) > 6 ? 6 : count($clients) ?>
			<?php for ($i = 0; $i < $limit; $i++) : ?>
				<div class="col-lg-6 my-3 my-lg-0">
					<div class="row flex-column flex-sm-row align-items-center">
						<a class="col-sm-5 mb-4 mb-sm-0" href="<?= base_url('client/'.str_replace(' ', '-', $clients[$i]->name)) ?>">
							<img class="rounded img-fluid hover-fade-out" src="<?= $clients[$i]->img ?>" alt="Image accompanying Circle testimonial">
						</a>
						<div class="col">
							<div class="mb-4">
								<img src="<?= $clients[$i]->logo ?>" alt="<?= $clients[$i]->name ?> company logo" class="icon icon-sm">
							</div>
							<div>
								<p class="h5">&ldquo;<?= $clients[$i]->content ?>&rdquo;</p>
							</div>
						</div>
					</div>
				</div>
			<?php endfor ?>
		</div>
	</div>
</section>
<section class="pb-0">
	<div class="container">
		<div class="row">
			<?php $limit = count($clients) > 6 ? 6 : count($clients) ?>
			<?php for ($i = 0; $i < $limit; $i++) : ?>
				<div class="col-md-6 col-lg-4 mb-3 mb-md-4 mb-lg-0">
					<div class="card h-100 hover-box-shadow">
						<div class="d-block bg-gradient rounded-top position-relative">
							<img class="card-img-top hover-fade-out" src="<?= $clients[$i]->img ?>" alt="Image accompanying Circle testimonial">
							<div class="badge badge-light">
								<img src="<?= $clients[$i]->logo ?>" alt="<?= $clients[$i]->name ?> company logo" class="icon icon-sm m-lg-1">
							</div>
						</div>
						<div class="card-body">
							<h3><?= $clients[$i]->name ?></h3>
							<p>
								<?= $clients[$i]->content ?>
							</p>
							<a href="<?= base_url('client/'.str_replace(' ', '-', $clients[$i]->name)) ?>" class="stretched-link">Read Story</a>
						</div>
					</div>
				</div>
			<?php endfor ?>
		</div>
	</div>
</section>
<section class="pb-0">
	<div class="container">
		<div class="row section-title justify-content-center text-center">
			<div class="col-md-9 col-lg-8 col-xl-7">
				<h3 class="display-4">Jumpstart your launch</h3>
				<div class="lead">Save hours on design and development and launch faster.</div>
			</div>
		</div>
		<div class="row justify-content-center text-center mt-md-n4">
			<div class="col-auto">
				<a href="#" class="btn btn-primary btn-lg">Buy Jumpstart</a>
			</div>
		</div>
	</div>
	<div class="divider divider-bottom bg-primary-3 mt-5"></div>
</section>