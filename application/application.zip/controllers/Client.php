<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('ClientModel', 'client');
	}

	public function index()
	{
		$content['step'] = $this->query->get_data_simple('step', [])->result();
		$content['feature'] = $this->query->get_data_simple('feature', [])->result();
		$content['carousel'] = $this->query->get_data_simple('image', ['name' => 'carousel-home'])->result();
		$content['image'] = $this->client->getImage('home');
		$content['clients'] = $this->query->get_data_simple('client', [])->result();
		$content['customers'] = $this->query->get_data_simple('customer', [])->result();
		$content['headers'] = $this->client->getHeader('home');
		$content['footer'] = $this->client->getHeader('footer');
		$data['content'] = $this->load->view('client/home', $content, TRUE);
		$data['seo'] = $this->client->getSEO('home');
		$this->load->view('client/index', $data, FALSE);
	}

	public function client($param = null){
		if ($param) {
			$content['client'] = $this->query->get_data_simple('client', ['name' => str_replace('-', ' ', $param)])->row();
			if (!$content['client'] || empty($content['client'])) show_404();
			$id = $content['client']->id;
			$content['random'] = $this->query->get_query("SELECT * FROM client WHERE id != $id ORDER BY RAND() LIMIT 1")->row();
			$content['headers'] = $this->client->getHeader('clients');
			$data['content'] = $this->load->view('client/client_detail', $content, TRUE);
			$data['seo'] = $this->client->getSEO('client-'.$content['client']->id);
		}else{
			$content['clients'] = $this->query->get_data_simple('client', [])->result();
			$content['headers'] = $this->client->getHeader('clients');
			$content['image'] = $this->query->get_data_simple('client', ['id' => $content['headers']['clients-header-1']['nb']])->row();
			$data['content'] = $this->load->view('client/clients', $content, TRUE);
		}
		$this->load->view('client/index', $data, FALSE);
	}

	public function save_email(){
		$this->query->save_data('email' , ['email' => $this->input->post('email')]);
		$response = (object) array('status' => 'success', 'message' => 'Thanks for your participation');
		echo json_encode($response);
	}

}

/* End of file Client.php */
/* Location: ./application/controllers/Client.php */